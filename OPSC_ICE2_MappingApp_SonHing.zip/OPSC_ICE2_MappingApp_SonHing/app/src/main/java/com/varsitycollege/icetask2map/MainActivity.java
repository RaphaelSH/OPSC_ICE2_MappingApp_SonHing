package com.varsitycollege.icetask2map;

import static com.varsitycollege.icetask2map.R.*;
import static com.varsitycollege.icetask2map.R.id.map;



import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends FragmentActivity implements OnMapReadyCallback {

    GoogleMap map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_main);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        map = googleMap;

        LatLng Gqebertha = new LatLng(-33.912770617711935, 25.5743345485481);
        map.addMarker(new MarkerOptions().position(Gqebertha).title("Gqebertha"));
        map.moveCamera(CameraUpdateFactory.newLatLng(Gqebertha));

    }
}